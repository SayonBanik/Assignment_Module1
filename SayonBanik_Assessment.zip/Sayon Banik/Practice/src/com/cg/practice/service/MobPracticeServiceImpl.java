package com.cg.practice.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.practice.dao.MobPracticeDaoImpl;
import com.cg.practice.dto.Mobile;
import com.cg.practice.exception.TestMobException;

public class MobPracticeServiceImpl implements MobPracticeService
{

	MobPracticeDaoImpl mobdao=null;
	
	
	
	public MobPracticeServiceImpl()
	{
		mobdao=new MobPracticeDaoImpl();
	}

	@Override
	public ArrayList<Mobile> getMobileDetails() throws TestMobException
	{
		
		return mobdao.getMobileDetails();
	}

	@Override
	public int addMobileDetails(Mobile ee) throws TestMobException
	{
		
		return mobdao.addMobileDetails(ee);
	}

	@Override
	public boolean ValidateName(String input) throws TestMobException
	{
		Boolean result=false;
		
		String pattern="[A-Z][a-z]+";
		
		if(Pattern.matches(pattern, input))
		{
			result=true;
		}
		
		return result;
	}

	@Override
	public boolean ValidateMobNumber(String input) throws TestMobException
	{
		
		Boolean result=false;
		
		String pattern="[1-9][0-9]{9}";
		
		if(Pattern.matches(pattern, input))
		{
			result=true;
		}
		
		return result;
	}

}
