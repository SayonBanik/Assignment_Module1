package com.cg.practice.service;

import java.util.ArrayList;

import com.cg.practice.dto.Mobile;
import com.cg.practice.exception.TestMobException;

public interface MobPracticeService 
{

	public ArrayList<Mobile> getMobileDetails() throws TestMobException;
	
	public int addMobileDetails(Mobile ee) throws TestMobException;
	
	public boolean ValidateName(String input) throws TestMobException;
	
	public boolean ValidateMobNumber(String input) throws TestMobException;
}
