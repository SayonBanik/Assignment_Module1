package com.cg.practice.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;



public class MobUtil
{

	public static String driver=null; 
	public static String url=null; 
	public static String uname=null; 
	public static String pass=null; 
	
	
	
	public static Connection getConnection() throws IOException, SQLException
	{
		Properties myProp=MobProp();
		
		driver=myProp.getProperty("dbDriver");
		url=myProp.getProperty("dbUrl");
		uname=myProp.getProperty("dbUser");
		pass=myProp.getProperty("dbPassword");
		
		Connection con=null;
		
		if(con==null)
		{
			con=DriverManager.getConnection(url,uname,pass);
			return con;
		}
		
		
		else
			return con;
		
		
		
	}
	

	public static Properties MobProp() throws IOException
	{
		
		FileReader fr=new FileReader("MyPracticeFile.properties");
		Properties mobProp=new Properties();
		mobProp.load(fr);
		
		
		return mobProp;
		
	}	

}