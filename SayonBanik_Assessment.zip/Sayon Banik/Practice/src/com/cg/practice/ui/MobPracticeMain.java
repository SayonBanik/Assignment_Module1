package com.cg.practice.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.practice.dto.Mobile;
import com.cg.practice.exception.TestMobException;
import com.cg.practice.service.MobPracticeServiceImpl;

public class MobPracticeMain {

	static MobPracticeServiceImpl mpsi=null;
	static Scanner sc=null;
	
	public static void main(String[] args)
	{
		int userInput;
		
		mpsi=new MobPracticeServiceImpl();
		sc=new Scanner(System.in);
		
		while(true)
		{
			System.out.println("Type 1 to Display Mobile Details \t Type 2 to add Mobile Details \t Type 3 to exit");
			userInput=sc.nextInt();
			
			switch(userInput)
			{
			
			case 1:DisplayMobDetails(); break;
			case 2:InsertMobDetails();break;
			default: System.exit(0);
			}
		}
	}

	private static void InsertMobDetails() 
	{
		int id=0;
		String name=null;
		String mobNo=null;
		String quantity=null;

		try 
		{
			System.out.println("Enter  mobile Id:");
			id=sc.nextInt();
			
			System.out.println("Enter mobile Name:");
			name=sc.next();
			
			if(mpsi.ValidateName(name))
			{
				System.out.println("Enter Mobile Number");
				mobNo=sc.next();
			}
			
			else
				throw new TestMobException("Name should start with Capital letter and then continue with small letters.Only characters are allowed");
			
			if(mpsi.ValidateMobNumber(mobNo))
			{
				System.out.println("Enter Quantity");
				quantity=sc.next();
			}
			else
				throw new TestMobException("Mobile Number should contain exact 10 digits.");
			
			
			Mobile mb=new Mobile(id,name,quantity);
			mpsi.addMobileDetails(mb);
		}
		
		catch (TestMobException e)
		{
			
			e.printStackTrace();
		}
		
	}

	private static void DisplayMobDetails()
	{
		
		try 
		{
			ArrayList<Mobile> mobList=mpsi.getMobileDetails();
			System.out.println("MOB_ID \t MOB_NAME \t MOB_QUANTITY");
			
			for(Mobile m:mobList)
			{
				System.out.println(m.getMobileId()+" \t "+m.getMobileName()+" \t  "+m.getMobileQty());
			}
		} 
		
		catch (TestMobException e)
		{
			
			e.printStackTrace();
		}
	}

}
