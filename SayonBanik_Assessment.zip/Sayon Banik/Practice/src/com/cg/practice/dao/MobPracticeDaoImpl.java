package com.cg.practice.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.practice.dto.Mobile;
import com.cg.practice.exception.TestMobException;
import com.cg.practice.util.MobUtil;

public class MobPracticeDaoImpl implements MobPracticeDao
{

	Connection con=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	
	
	
	@Override
	public ArrayList<Mobile> getMobileDetails() throws TestMobException
	{
	
		ArrayList<Mobile> mobList=null;
		try 
		{
			mobList=new ArrayList<Mobile>();
			con=MobUtil.getConnection();
			
			pst=con.prepareStatement("SELECT * FROM TESTMOBILE157998");
			rs=pst.executeQuery();
			
			
			while(rs.next())
			{
				mobList.add(new Mobile(rs.getInt("MOB_ID"),rs.getString("MOB_NAME"),rs.getString("MOB_QUANTITY")));
			}
		} 
		
		catch (Exception e)
		{
			
			e.printStackTrace();
		}
		
		
		return mobList;
	}

	@Override
	public int addMobileDetails(Mobile ee) throws TestMobException
	{
		
		int status=0;
		
		try 
		{
			con=MobUtil.getConnection();
			pst=con.prepareStatement("INSERT INTO TESTMOBILE157998 VALUES(?,?,?)");
			pst.setInt(1, ee.getMobileId());
			pst.setString(2, ee.getMobileName());
			pst.setString(3, ee.getMobileQty());
			
			status=pst.executeUpdate();
		} 
		
		catch (IOException | SQLException e)
		{
			
			e.printStackTrace();
		}
		
		
		return status;
	}

	
}
