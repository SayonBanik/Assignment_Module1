package com.cg.practice.dao;

import java.util.ArrayList;

import com.cg.practice.dto.Mobile;
import com.cg.practice.exception.TestMobException;

public interface MobPracticeDao
{

	public ArrayList<Mobile> getMobileDetails() throws TestMobException;
	
	public int addMobileDetails(Mobile ee) throws TestMobException;
}
