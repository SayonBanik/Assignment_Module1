package com.cg.practice.dto;

public class Mobile
{

	int mobileId=0;
	String mobileName=null;
	String mobileQty=null;
	
	public Mobile()
	{
		super();
		
	}

	public Mobile(int mobileId, String mobileName, String mobileQty) {
		super();
		this.mobileId = mobileId;
		this.mobileName = mobileName;
		this.mobileQty = mobileQty;
	}

	@Override
	public String toString() {
		return "Mobile [mobileId=" + mobileId + ", mobileName=" + mobileName + ", mobileQty=" + mobileQty + "]";
	}

	public int getMobileId() {
		return mobileId;
	}

	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}

	public String getMobileName() {
		return mobileName;
	}

	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}

	public String getMobileQty() {
		return mobileQty;
	}

	public void setMobileQty(String mobileQty) {
		this.mobileQty = mobileQty;
	}
	
	
}
