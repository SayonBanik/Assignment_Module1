package com.cg.practice.exception;

public class TestMobException extends Exception
{

	public TestMobException(String message) 
	{
		super(message);
		
	}

	public TestMobException(String message, Throwable cause) 
	{
		super(message,cause);
		
	}
	
}
