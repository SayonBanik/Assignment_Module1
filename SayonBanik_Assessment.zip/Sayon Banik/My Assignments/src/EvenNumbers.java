import java.io.*;
import java.util.Scanner;

public class EvenNumbers {

	public static void main(String[] args)
	{
		File file=new File("D:\\Sayon Banik\\My Assignments\\src\\sayon\\numbers.txt");
		String line=null;
		String [] lineVector;
		int input;
		
		try
		{
			Scanner sc=new Scanner(file);
		
			line=sc.nextLine();
			
			
			lineVector=line.split(",");
			
	/*		while(sc.hasNextLine())
			{
				
				System.out.println(sc.nextLine());
			}
	*/		
			
			lineVector=line.split(",");
			
			
			for(int i=0;i<=10;i++)
			{
				input=Integer.parseInt(lineVector[i]);
				
				if(input%2==0)
					System.out.print(input+",");
			}
			
		}
		
		catch (IOException e)
		{
			
			e.printStackTrace();
		}

	}

}
