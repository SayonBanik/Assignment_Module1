package sayon;

import java.io.*;

import java.util.Scanner;

public class ReverseFileContent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	//	File myFile =new File("Sayon.txt");
		
		
		
		
		String str="This is a normal text. ";
		
		
		try
		{
			FileWriter fw=new FileWriter("Sayon.txt");
			for(int i=0;i<str.length();i++)
			{
				fw.write(str.charAt(i));
			}
			
			fw.close();
			
			FileReader fr=new FileReader("Sayon.txt");
			BufferedReader br=new BufferedReader(fr);
			
	//		for(int i=0;i<str.length();i++)
	//		{
				String inp=br.readLine();
	//		}
			
			StringBuilder input=new StringBuilder();
			input=input.append(inp);
			input.reverse();
		//    input=input.append("/n");
			
			
			FileWriter fw1=new FileWriter("Sayon.txt",true);
			for(int i=0;i<input.length();i++)
			{
				fw1.write(input.charAt(i));
			}
			
			fw1.close();
			
			
		}
		
		catch (IOException e) {
			
			e.printStackTrace();
		}

	}
		
		


}
