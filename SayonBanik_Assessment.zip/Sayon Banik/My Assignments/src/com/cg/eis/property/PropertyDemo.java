package com.cg.eis.property;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertyDemo {

	public static void main(String[] args)
	{


		try
		{
			FileOutputStream fos=new FileOutputStream("PropertyProps.properties");
			Properties prop=new Properties();
			prop.setProperty("UserName", "Sayon");
			prop.setProperty("Password", "CapG1234");
			prop.store(fos, "This is database information");
			
			FileInputStream fis=new FileInputStream("PropertyProps.properties");
			Properties prop1=new Properties();
			prop1.load(fis);
			
			
			String unm=prop1.getProperty("UserName");
			String pwd=prop1.getProperty("Password");
			System.out.println("UserName:"+unm+" Password:"+pwd);


		}
		
		catch ( IOException e)
		{
			
			e.printStackTrace();
		}

	}


}
