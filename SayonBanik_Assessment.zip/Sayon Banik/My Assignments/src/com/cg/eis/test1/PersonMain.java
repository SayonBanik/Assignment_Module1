package com.cg.eis.test1;

import java.util.Scanner;

public class PersonMain {

	public static void main(String[] args)
	{
		String firstName,lastName,g;
		char gender;
		
		Scanner sc=new Scanner(System.in);
		
		
		System.out.println("Enter First Name:");
		firstName=sc.next();
		
		System.out.println("Enter Last Name:");
		lastName=sc.next();
		
		System.out.println("Enter Gender:");
		g=sc.next();
		
		gender=g.charAt(0);
		
		
		Person p=new Person(firstName,lastName,gender);
		
		
		p.Display();

	}

}
