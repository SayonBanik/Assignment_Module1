package com.cg.eis.test1;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;



//@RunWith(Parameterized.class)
public class PersonTest
{

//	private int input;
//	private int expected;
	
/*	@Parameterized.Parameters
	public static Collection data()
	{
		return Arrays.asList(new Object[][]
				{{"Sayon","Sayon"},{"Sumit","Sumit"}});
		
	}
	
	public PersonTest()
	{
		this.expected=expected;
	}
*/	
	@Test
	public void TestFirstName()
	{
		char M = 0;
		Person per=new Person("Sayon","Banik",M);
		System.out.println("Running parameterized tests");
		assertEquals("Sayon", per.getFirstName());
	}
	
	@Test
	public void TestLastName()
	{
		char M = 0;
		Person per=new Person("Sayon","Banik",M);
		System.out.println("Running parameterized tests");
		assertEquals("Banik", per.getLastName());
	}
	
	@Test
	public void TestGender()
	{
		String age="M";
		char Age = age.charAt(0);
		Person per=new Person("Sayon","Banik",Age);
		System.out.println("Running parameterized tests");
		assertEquals("M", (String)Character.toString(per.getGender()));
	}
	
	@AfterClass
	public static void tearDown() {
		
		String age="M";
		char Age = age.charAt(0);
		System.out.println();
		Person per=new Person("Sayon","Banik",Age);
		per.Display();
		System.out.println("tearDown is called once "+" Before the execution of "+" all test cases");
	}
}
