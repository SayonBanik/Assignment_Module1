package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.dto.BookingBean;
import com.capgemini.dto.TrainBean;
import com.capgemini.exception.BookingException;

public interface TrainService 
{

	public ArrayList<TrainBean> retrieveTrainDetails() throws BookingException;
	
	public int bookTicket(BookingBean bookingBean,int tId,int nos) throws BookingException;
	
	public boolean ValidateCustId(String cId) throws BookingException;
	
	public void UpdateSeats(int tId,int nos) throws BookingException;
	
}
