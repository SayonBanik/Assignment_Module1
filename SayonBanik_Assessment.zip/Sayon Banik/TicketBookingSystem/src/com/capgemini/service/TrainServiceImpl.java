package com.capgemini.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.capgemini.dao.TrainDaoImpl;
import com.capgemini.dto.BookingBean;
import com.capgemini.dto.TrainBean;
import com.capgemini.exception.BookingException;


public class TrainServiceImpl implements TrainService
{

	TrainDaoImpl tdi=null;
	
	public TrainServiceImpl()
	{
		tdi=new TrainDaoImpl();
	}

	@Override
	public ArrayList<TrainBean> retrieveTrainDetails() throws BookingException
	{
		
		return tdi.retrieveTrainDetails();
	}

	@Override
	public int bookTicket(BookingBean bookingBean,int tId,int nos) throws BookingException
	{
		
		return tdi.bookTicket(bookingBean,tId,nos);
	}

	@Override
	public boolean ValidateCustId(String cId) throws BookingException 
	{
		boolean status=false;
		String cIdPattern="[A-Z][0-9]{6}";
		
		if(Pattern.matches(cIdPattern,cId ))
		{
			status=true;
		}
		
		else
		{
			throw new BookingException("Invalid Name.Should start with capital and then 6 characters are allowed. Example:A111111");
		}
		
		return status;
	}

	@Override
	public void UpdateSeats(int tId,int nos) throws BookingException
	{
		tdi.UpdateSeats(tId,nos);
		
	}



}

	

