package com.capgemini.junit;

import java.util.ArrayList;

import org.junit.Assert;
import org.junit.Test;

import com.capgemini.exception.BookingException;


public class BookingTest 
{

	@Test
	public void test1() throws BookingException
	{
		
		
	}
}
