package com.capgemini.exception;



public class BookingException extends Exception
{

	String message;
	
		
	public BookingException(String message)
	{
		super(message);
			
	}
		
	public BookingException(String message, Throwable cause)
	{
		super(message,cause);
			
			
	}

}
