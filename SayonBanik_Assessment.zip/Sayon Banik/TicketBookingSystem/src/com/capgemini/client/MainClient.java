package com.capgemini.client;

import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.dto.BookingBean;
import com.capgemini.dto.TrainBean;
import com.capgemini.exception.BookingException;
import com.capgemini.service.TrainService;
import com.capgemini.service.TrainServiceImpl;

public class MainClient
{
	
	static Scanner sc=null;
	static int temp=(int)Math.random()+100;
	static TrainService tsi=null;
	static int nos=0;
	static int tId=0;

	public static void main(String[] args) throws BookingException
	{
		
		int choise=0;
		sc=new Scanner(System.in);
		tsi=new TrainServiceImpl();
		
		while(true)
		{
			System.out.println("What do you want to do?");
			System.out.println("1. Book Ticket\n2. Exit");
			
			choise=sc.nextInt();
			
	
			switch(choise)
			{
			case 1:DisplayTrainDetails();break;
			default: System.exit(0);
				
			}
		}
	}

	private static void DisplayTrainDetails() throws BookingException
	{
		
		ArrayList<TrainBean> trainList=null;
		
		try 
		{
			trainList=tsi.retrieveTrainDetails();
			
			System.out.println("TrainId"+"\t"+"TrainType"+"\t"+"FromStop"+"\t"+"ToStop"+"\t"+"Available Seats"+"\t"+"Fare"+"\t"+"Date Of Journey");
			
			for(TrainBean tb:trainList)
			{
				System.out.println(tb.getTrainId()+"\t"+tb.getTrainType()+"\t"+tb.getFromStop()+" \t "+"\t"+tb.getToStop()+"\t"+"\t"+tb.getAvailableSeats()+"\t"+tb.getFare()+"\t"+tb.getDateOfJourney());
				
			}
		} 
		
	
		catch (BookingException e) 
		{
			
			e.printStackTrace();
		}
		
		
		System.out.println("Enter customer Id:");
		String cId=sc.next();
		
		if(tsi.ValidateCustId(cId))
		{
			System.out.println("Please enter the train Id:");
			tId=sc.nextInt();
		}
		
		if(tId==1||tId==2||tId==3||tId==4)
		{
			System.out.println("Enter Number of seats:");
			nos=sc.nextInt();
		}
		
		else
		{
			throw new BookingException("Train Id should be from existing train Ids");
		}
		
		int bId=temp;
		
		BookingBean bb=new BookingBean(bId,nos,tId,cId);
		
		int result;
		
		result=tsi.bookTicket(bb,tId,nos);
		
		
		
		if(result==0)
		{
			System.out.println("Sorry No Seats Available");
		}
		
		else
		{
			
			System.out.println("Your booking id is"+bId);
		}
		
		
		tsi.UpdateSeats(tId,nos);
		
		temp++;
		
	}
	
	

}
