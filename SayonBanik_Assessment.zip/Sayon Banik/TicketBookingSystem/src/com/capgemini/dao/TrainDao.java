package com.capgemini.dao;

import java.util.ArrayList;

import com.capgemini.dto.BookingBean;
import com.capgemini.dto.TrainBean;
import com.capgemini.exception.BookingException;


public interface TrainDao
{

	public ArrayList<TrainBean> retrieveTrainDetails() throws BookingException;
	
	public int bookTicket(BookingBean bookingBean,int tId,int nos) throws BookingException;
	
	public void UpdateSeats(int tId,int nos) throws BookingException;
}
