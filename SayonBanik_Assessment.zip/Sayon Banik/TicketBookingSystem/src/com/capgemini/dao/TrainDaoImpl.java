package com.capgemini.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.capgemini.dto.BookingBean;

//import org.apache.log4j.Logger;

import com.capgemini.dto.TrainBean;
import com.capgemini.exception.BookingException;
import com.capgemini.util.TBSUtil;


public class TrainDaoImpl implements TrainDao
{

//	Logger daoLogger=null;
	Connection con=null;
	Statement st=null;
	PreparedStatement pst,pst1,pst2,pst3=null;
	ResultSet rs,rs2,rs3=null;
	
	
	@Override
	public ArrayList<TrainBean> retrieveTrainDetails() throws BookingException
	{
		ArrayList<TrainBean> tktList=null;
		try
		{
			tktList=new ArrayList<TrainBean>();
			con=TBSUtil.getConn();
			pst=con.prepareStatement("SELECT * FROM TrainDetails");
			rs=pst.executeQuery();
			
			while(rs.next())
			{
				tktList.add(new TrainBean(rs.getInt("trainId"),rs.getString("trainType"),rs.getDate("dateOfJourney"),rs.getString("fromStop"),rs.getString("toStop"),rs.getInt("availableSeats"),rs.getInt("fare")));
			}
			
		} 
		
		catch (SQLException | IOException e)
		{
			
			e.printStackTrace();
		}
		
		return tktList;
	}

	@Override
	public int bookTicket(BookingBean bookingBean,int tId,int nos) throws BookingException
	{
		int status=0;
		int a=0;
		try
		{
			con=TBSUtil.getConn();
			pst2=con.prepareStatement("SELECT availableSeats FROM TrainDetails WHERE trainId=?");
			pst2.setInt(1, tId);
			rs2=pst2.executeQuery();
			
			while(rs2.next())
			{
				a=rs2.getInt("availableSeats");
			}
			
			
			if(a>0 && a>nos )
			{
				pst1=con.prepareStatement("INSERT INTO BookingDetails VALUES(?,?,?,?)");
				pst1.setInt(1, bookingBean.getBookingId());
				pst1.setString(2, bookingBean.getCustId());
				pst1.setInt(3, bookingBean.getTrainId());
				pst1.setInt(4, bookingBean.getNoOfSeats());
				
				status=pst1.executeUpdate();
				
			}
		} 
		
		catch (SQLException | IOException e)
		{
			
			e.printStackTrace();
		}
		return status;
		
	}

	@Override
	public void UpdateSeats(int tId,int nos) throws BookingException
	{
		
		try 
		{
			con=TBSUtil.getConn();
			pst3=con.prepareStatement("UPDATE TrainDetails SET availableSeats=availableSeats-? WHERE trainId=?");
			pst3.setInt(1, nos);
			pst3.setInt(2, tId);
			pst3.executeUpdate();
			
		} 
		
		catch (SQLException | IOException e)
		{
			
			e.printStackTrace();
		}
	}

	
}
