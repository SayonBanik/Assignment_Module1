package com.cg;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


import sayon.CalculatorTest;
import sayon.CalculatorTestT;

@RunWith(Suite.class)
@Suite.SuiteClasses({CalculatorTest.class,CalculatorTestT.class, HelloWorldTest.class})

 public class TestMySuit
 {

		@BeforeClass
		public static void setUpBeforeClass() throws Exception {
			System.out.println("Now running the test suite");
		}
		
		@AfterClass
		public static void tearDownAfterClass() throws Exception {
			System.out.println("The test suite is completed");
		}
		
}
	
