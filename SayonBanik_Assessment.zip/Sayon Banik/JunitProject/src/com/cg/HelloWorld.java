package com.cg;
import static org.junit.Assert.*;
import org.junit.Test;

public class HelloWorld {

	public String say()
		{
			return("Hello World!");
		}
		
}


