package com.cg.ems.dao;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUtil;

public class EmpDaoImpl implements EmpDao
{

	Logger daoLogger=null;
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	
	
	@Override
	public ArrayList<Employee> getAllEmp() throws EmployeeException
	{
		ArrayList<Employee> empList=null;
		daoLogger=Logger.getLogger(EmpDaoImpl.class);
		PropertyConfigurator.configure("D:\\Sayon Banik\\Employee Management System\\resources\\log4j.properties");
		
		try
		{
			empList=new ArrayList<Employee>();
			con=DBUtil.getConn();
			String selectqry="SELECT * FROM EMP_157998";
			st=con.createStatement();
			rs=st.executeQuery(selectqry);
			while(rs.next())
			{
				empList.add(new Employee(rs.getInt("EMP_ID"),
						rs.getString("EMP_NAME"),
						rs.getFloat("EMP_SALARY")));
			}
		} 
		
		catch (Exception e)
		{
			
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		} 
		
		finally
		{
			try
			{
				st.close();
				rs.close();
				con.close();
			}
			
			catch(SQLException e)
			{
				e.printStackTrace();
				daoLogger.error(e.getMessage());
				throw new EmployeeException(e.getMessage());
			}
		}
		daoLogger.info("All data Retrieved:"+empList);
		return empList;
	}

	@Override
	public int addEmp(Employee ee) throws EmployeeException
	{
		int data;
		try
		{
			con=DBUtil.getConn();
			String insertQry="INSERT INTO EMP_157998 VALUES(?,?,?)";
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, ee.getEmpId());
			pst.setString(2, ee.getEmpName());
			pst.setFloat(3, ee.getEmpSal());
			data=pst.executeUpdate();
			
		}
		
		catch (Exception e) {
			
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		
		return data;
	}

	
}
