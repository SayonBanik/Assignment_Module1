package com.cg.ems.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmpService;
import com.cg.ems.service.EmpServiceImpl;

public class TestEmpMGSClient
{
	static EmpService empService=null;
	static Scanner sc=null;
	
	public static void main(String [] args)
	{
		sc=new Scanner(System.in);
		empService=new EmpServiceImpl();
		System.out.println("****** Welcome to EMS ******");
		int choice=0;
		while(true)
		{
			System.out.println("What do you want to do?");;
			System.out.println("\t 1: Add Employee \t 2: Show All Employee \t 3:Update Employee \t 4: Delete Employee \t 5: Exit");
			System.out.println("Enter your choice");
			choice = sc.nextInt();
			switch(choice)
			{
			case 1: insertEmp();break;
			case 2: displayAllemp();break;
			default: System.exit(0);
			}
		}
	}

	private static void displayAllemp()
	{
		ArrayList <Employee> empsList=null;
		try
		{
			empsList=empService.getAllEmp();
			System.out.println(" \t EMPID \tEMPNAME \tEMPSAL");
			for(Employee ee:empsList)
			{
				System.out.println("\t"+ee.getEmpId()+"\t"+ee.getEmpName()+"\t"+ee.getEmpSal());
			}
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
	}

	private static void insertEmp()
	{
		
	
		try
		{
			System.out.println("Enter your Emp Id");
			int eId=sc.nextInt();
			System.out.println("Enter Name");
			String enm=sc.next();
			float esl=0;
			if(empService.validateEmpName(enm))
			{
				System.out.println("Enter Salary:");
				esl=sc.nextFloat();
				Employee e1=new Employee(eId,enm,esl);
				int dataInserted=empService.addEmp(e1);
				if(dataInserted==1)
				{
					displayAllemp();
				}
				else
				{
					System.out.println("Sorry data is not inserted");
				}
			}
			else
				System.out.println("Please Enter the name in correct format");
		}
		catch (EmployeeException e) 
		{
		
			e.printStackTrace();
		}
	}
}
