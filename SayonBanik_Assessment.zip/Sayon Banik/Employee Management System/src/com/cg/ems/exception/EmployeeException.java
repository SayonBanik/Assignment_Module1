package com.cg.ems.exception;

public class EmployeeException extends Exception
{

	String message;
	static ErrorCode code;
	
	public EmployeeException(String message)
	{
		super(message);
		
	}
	
	public EmployeeException(String message, Throwable cause, ErrorCode code)
	{
		super(message,cause);
		
		
	}

	
}
