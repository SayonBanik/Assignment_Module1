import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class TestEmpUpdateDemo
{
	public static void main(String [] args)
	{
		Scanner sc=new Scanner(System.in);
		
		String empName = null;
		int empSalary = 0;
		
		System.out.println("Enter what to update EMP_NAME or EMP_SALARY");
		String whatToUpdate=sc.next();
		
		if(whatToUpdate.equals("EMP_NAME"))
		{
			System.out.println("Enter Employee Name to update record:");
			empName=sc.next();
		}
		
		else if(whatToUpdate.equals("EMP_SALARY"))
		{
			System.out.println("Enter Employee salary to update record:");
			empSalary=sc.nextInt();
		}
		
		System.out.println("Enter Employee id to update record:");
		int empId=sc.nextInt();
		
		//String insertQry="UPDATE EMP_157998 SET ?=? WHERE EMP_ID = ?";
				
				Connection con=null;
				PreparedStatement pst=null;
				
				try
				{
					
					Class.forName("oracle.jdbc.driver.OracleDriver");
					con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","Lab1btrg13","lab1boracle");
					
					
					
					if(whatToUpdate.equals("EMP_NAME"))
					{	
						pst=con.prepareStatement("UPDATE EMP_157998 SET EMP_NAME=? WHERE EMP_ID = ?");
						pst.setString(1,empName);
					}
					
					else if(whatToUpdate.equals("EMP_SALARY"))
					{	
						pst=con.prepareStatement("UPDATE EMP_157998 SET EMP_SALARY=? WHERE EMP_ID = ?");
						pst.setInt(1,empSalary);
					}
					
					pst.setInt(2, empId);
					
					int data=pst.executeUpdate();
					System.out.println(data + " record is updated in the table");
				
				con.close();
					
				}
				
				catch (ClassNotFoundException | SQLException ee) {
					
					ee.printStackTrace();
				}
		}
}
