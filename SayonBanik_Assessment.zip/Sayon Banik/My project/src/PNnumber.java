
public class PNnumber {

	public static void main(String [] args)
	{
		try
		{
			int a= Integer.parseInt(args[0]);
			
			String s=(a<0)?"The number is negative":"The number is positive";
				
			System.out.println(s);
		}
		catch(Exception e)
		{
			System.out.print("Please enter a number");
		}
		
	}
}
