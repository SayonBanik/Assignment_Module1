import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ArrayListSort
{

	public static void main(String [] args)
	{
		
		int length;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the number of elements");
		length=sc.nextInt();
		
		
		ArrayList<String> arr=new ArrayList<String>();
		
		
		System.out.println("Enter "+length+"  elements");
		
		for(int i=0;i<length;i++)
			arr.add(sc.next());
			
		System.out.println("Array before sorting");
			for(String m:arr) {
				System.out.println(m);
			}
		
		Collections.sort(arr);	
			
		System.out.println("Array after sorting");
			for(String m:arr) {
				System.out.println(m);
			}
	}
}
