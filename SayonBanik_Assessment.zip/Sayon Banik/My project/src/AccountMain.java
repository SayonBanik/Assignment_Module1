
public class AccountMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person obj1=new Person("Smith",(float)30.0,2000.00);
		SavingsAccount sv=new SavingsAccount();
		CurrentAccount cr=new CurrentAccount();
		
		obj1.ac.setBalance(287000,2000,0);
		System.out.println("Current balance of Smith is:"+obj1.ac.getBalance());
		sv.Withdraw(obj1.ac.getBalance());
		
		Person obj2=new Person("Kathy",(float)35.25,3000.00);
		
		obj2.ac.setBalance(287001,3000,0);
		System.out.println("Current balance of Kathy is:"+obj2.ac.getBalance());
		sv.Withdraw(obj2.ac.getBalance());
		
		System.out.println("Withdrawal amount=50000");
		System.out.println((cr.withdraw(50000))?"Money can be withdrawn":"Maximum withdrawal amount is rs.40000,Money cannot be withdrawn");
		
		System.out.println("Withdrawal amount=2000");
		System.out.println((cr.withdraw(2000))?"Money can be withdrawn":"Maximum withdrawal amount is rs.40000,Money cannot be withdrawn");

	}

}
