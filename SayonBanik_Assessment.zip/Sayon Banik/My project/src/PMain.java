import java.util.Scanner;

public class PMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		float sAge = 0;
		float kAge = 0;
		try {
			System.out.println("Enter age of Smith:");
			sAge=sc.nextFloat();
			
			System.out.println("Enter age of Kathy:");
			kAge=sc.nextFloat();
			
			if(sAge<15 || kAge<15) 
				throw new UserRestrictedException();
		}
		catch(UserRestrictedException e) {
			System.out.println(e);
		}
		
		Person obj1=new Person("Smith",(float) sAge,2000.00);
		
		Person obj2=new Person("Kathy",(float) kAge,3000.00);
		
		obj1.ac.setBalance(287000,2000,2000);
		System.out.println("Current updated balance for Smith is:"+obj1.ac.getBalance());
		
		obj1.ac.setBalance(287001,3000,2000);
		System.out.println("Current updated balance for Kathy is:"+obj1.ac.getBalance());
	}

}
