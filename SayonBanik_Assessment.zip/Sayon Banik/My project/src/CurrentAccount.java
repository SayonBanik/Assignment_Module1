public class CurrentAccount extends Account {
	
	int overdraftLimit=40000;
	
	public CurrentAccount() {
		super();
	}

	public boolean withdraw(double moneyToWithdraw)
	{
		if(overdraftLimit<=moneyToWithdraw)
			return false;
		else
			return true;
	}
}
