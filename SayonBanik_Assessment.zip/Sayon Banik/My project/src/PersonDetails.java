
public class PersonDetails {

	public static void main(String [] args)
	{
		System.out.println("Person Details:");
		System.out.println("_______________");
		System.out.println("");
		System.out.println("First Name: Sayon");
		System.out.println("Last Name: Banik");
		System.out.println("Gender: M");
		System.out.println("Age: 22");
		System.out.println("Weight: 62.25");
	}
}
