
package com.cg.eis.service;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.cg.eis.bean.Employee;



public class ServicesOffered implements EmployeeService 
{
	
	
	
	

	@Override
	public void Services(String scheme) {
		// TODO Auto-generated method stub
		
		if(scheme=="A")
			System.out.println("Services offered in SchemeA:a ");
		
		else if(scheme=="B")
			System.out.println("Services offered in SchemeB:b ");
		
		else if(scheme=="C")
			System.out.println("Services offered in SchemeC:c ");
		else
			System.out.println("No Service Available ");
		
	}

	
}
