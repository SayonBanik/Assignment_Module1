package com.cg.eis.pl;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.UserDefinedException;
//import com.cg.eis.bean.Employee;
import com.cg.eis.service.ServicesOffered;

public class UserInformation {

	static HashMap<String,Employee> list=new HashMap<String,Employee>();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub


			int id=0,salary=0,empNumber=0,temp=1;
			String name=null,designation=null,scheme=null,userResponse=null; 
			
			
			Scanner sc=new Scanner(System.in);
			
			
			System.out.println("Enter number of Employees:");
			empNumber=sc.nextInt();
			
			
			
			
		do {
			
			Employee emp=new Employee();
			
			try {
			System.out.println("Enter id of "+temp+"th Employee :");
			id=sc.nextInt();
			emp.setId(id);
			
			System.out.println("Enter Name of "+temp+"th Employee :");
			name=sc.next();
			emp.setName(name);
			
			System.out.println("Enter Salary of "+temp+"th Employee :");
			salary=sc.nextInt();
			emp.setSalary(salary);
			
			System.out.println("Enter Designation of "+temp+"th Employee:");
			designation=sc.next();
			emp.setDesignation(designation);
					
			
			emp.setScheme();

			
			if(salary<3000)
				throw new UserDefinedException();
			
			}
			
			catch(UserDefinedException e)
			{
				System.out.println(e);
			}
			
			
			
			emp.DisplayEmployee();
			
			ServicesOffered svcOffered=new ServicesOffered();
			svcOffered.Services(emp.getScheme());
			
			addEmployee(emp);
					
			temp++;
			
			
			
			
		}while(temp<=empNumber);
	
		
		System.out.println("Do you want to see any employee details? Type yes to see. Else type no");
		userResponse=sc.next();
		
		if(userResponse.equals("yes")) {
			System.out.println("Enter scheme to see employee details:");
			String userSchemeInput=sc.next();
			SearchEmployee(userSchemeInput);
		}
		
		
		System.out.println("Do you want to delete any employee details? Type yes to delete. Else type no");
		userResponse=sc.next();
		
		if(userResponse.equals("yes")) {
			System.out.println("Enter id to delete employee details:");
			int deleteId=sc.nextInt();
			DeleteEmployee(deleteId);
		}
	
		System.out.println("Before sorting");
		System.out.println(list);
		
		
		System.out.println("After sorting based on employee's salary");
		
		List<Entry<String,Employee>> arrList=new LinkedList<Entry<String,Employee>>(list.entrySet());
		Collections.sort(arrList, new Comparator<Entry<String,Employee>>() {
			
			
			public int compare(Entry<String,Employee> obj1, Entry<String,Employee> obj2) {
				return obj1.getValue().getSalary()-obj2.getValue().getSalary();
				
				
			}
			
		});
		
		System.out.println(arrList);
	
	}


	
	private static void DeleteEmployee(int deleteId) {
		// TODO Auto-generated method stub
		
		Set<Map.Entry<String,Employee>> mapSet=list.entrySet();
		Iterator<Map.Entry<String,Employee>> it=mapSet.iterator();
		
		while(it.hasNext()) {
			Map.Entry<String,Employee> entry=it.next();
			
			if(deleteId==(entry.getValue().getId())) {
				it.remove();
				System.out.println("The item is deleted...");
				
			}
			
		}
		
		System.out.println("The modified hashmap is:"+list);
		
	}



	private static void SearchEmployee(String userSchemeInput) {
		// TODO Auto-generated method stub
		Set<Map.Entry<String,Employee>> mapSet=list.entrySet();
		Iterator<Map.Entry<String,Employee>> it=mapSet.iterator();
		
		while(it.hasNext()) {
			Map.Entry<String,Employee> entry=it.next();
			
			if(userSchemeInput.equals(entry.getKey())) {
				
				System.out.println(entry.getValue().toString());
				
			}
			
		}
		
	}



	public static void addEmployee(Employee emp) {
		
		list.put(emp.getScheme(), emp);
	}
	
	


}
