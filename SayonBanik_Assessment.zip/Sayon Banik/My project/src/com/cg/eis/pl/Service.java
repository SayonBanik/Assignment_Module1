package com.cg.eis.pl;

import java.io.Serializable;

public class Service implements Serializable {
	
	int id,salary;
	String name,designation;

	public Service(int id, int salary, String name, String designation) {
		super();
		this.id = id;
		this.salary = salary;
		this.name = name;
		this.designation = designation;
	}

	@Override
	public String toString() {
		return "Service [id=" + id + ", salary=" + salary + ", name=" + name + ", designation=" + designation + "]";
	}
	
	
	
	
	

}
