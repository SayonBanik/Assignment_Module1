package com.cg.eis.pl;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.ServicesOffered;

public class UserInfoDataBase
{

	static Connection con=null;
	static PreparedStatement pst=null;
	static ResultSet rs=null;
	
	public static void main(String[] args)
	{
	

			int id=0,salary=0,empNumber=0,temp=1;
			String name=null,designation=null,scheme=null,userResponse=null; 
			
			
			Scanner sc=new Scanner(System.in);
			
			
			System.out.println("Enter number of Employees:");
			empNumber=sc.nextInt();
			
			
			
			
		do {
			
			Employee emp=new Employee();
			
			try
			{
			
				
				System.out.println("Enter id of "+temp+"th Employee :");
				id=sc.nextInt();
				emp.setId(id);
				
				System.out.println("Enter Name of "+temp+"th Employee :");
				name=sc.next();
				emp.setName(name);
				
				System.out.println("Enter Salary of "+temp+"th Employee :");
				salary=sc.nextInt();
				emp.setSalary(salary);
				
				System.out.println("Enter Designation of "+temp+"th Employee:");
				designation=sc.next();
				emp.setDesignation(designation);
						
				
				emp.setScheme();
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","Lab1btrg13","lab1boracle");
				
				
				pst=con.prepareStatement("INSERT INTO EMPLOYEE157998 VALUES(?,?,?,?)");
				
				pst.setInt(1, id);
				pst.setString(2, name);
				pst.setInt(3, salary);
				pst.setString(4, designation);
	
				int noOfRecAffected=pst.executeUpdate();
				System.out.println(noOfRecAffected + " record is inserted in the table");
				
				if(salary<3000) 
				
					throw new ExceptionCheck();
				
				}
				
			catch(ExceptionCheck | ClassNotFoundException | SQLException e)
			{
				System.out.println(e);
			}
			
			emp.DisplayEmployee();
	
			temp++;
			
		}while(temp<=empNumber);
		
		Display();
		DeleteRecord();
		
	}

	private static void DeleteRecord()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee ID to delete record:");
		int empId=sc.nextInt();
		
		String insertQry="DELETE FROM EMPLOYEE157998 WHERE EMP_ID=?";
		
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","Lab1btrg13","lab1boracle");
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, empId);
			
			int noOfRecAffected=pst.executeUpdate();
			System.out.println(noOfRecAffected + " record is deleted from the table");
			
			Display();
			
		}
		
		catch (ClassNotFoundException | SQLException ee) {
			
			ee.printStackTrace();
		}
		
	}

	private static void Display()
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","Lab1btrg13","lab1boracle");
			
			pst=con.prepareStatement("SELECT * FROM EMPLOYEE157998");
			rs=pst.executeQuery();
			while(rs.next())
			{
			System.out.println(":"+rs.getInt("EMP_ID")+":"+rs.getString("EMP_NAME")+":"+rs.getInt("EMP_SALARY")+":"+rs.getString("EMP_DESIGNATION"));
			}
		}
		
		catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
		
	}

		
}
