package com.cg.eis.pl;

public class ExceptionCheck extends Exception {
	String message;
	int salary;
	
	public ExceptionCheck() 
	{
		message="Error,Salary should be greater than rs. 3000. Kindly check again and retry";
	}
	
	public ExceptionCheck(int salary) 
	{
		this.salary=salary;
	}
	
	public String TestException()
	{
		if(salary<3000)
			message="Error,Salary should be greater than rs. 3000. Kindly check again and retry";
		
		return message;
	}

	@Override
	public String toString() {
		return message;
	}
	
	

}
