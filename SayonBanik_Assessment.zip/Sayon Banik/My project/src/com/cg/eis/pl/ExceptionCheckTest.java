package com.cg.eis.pl;

import static org.junit.Assert.assertEquals;

import org.junit.Test;


public class ExceptionCheckTest
{

	@Test
	public void TestSalary()
	{
		ExceptionCheck expCheck=new ExceptionCheck(2000);
		System.out.println("Running parameterized tests");
		assertEquals("Error,Salary should be greater than rs. 3000. Kindly check again and retry",expCheck.TestException());
	}
}
