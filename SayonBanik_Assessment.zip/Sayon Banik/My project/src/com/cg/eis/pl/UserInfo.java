package com.cg.eis.pl;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.UserDefinedException;
//import com.cg.eis.bean.Employee;
import com.cg.eis.service.*;

public class UserInfo {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub


			int id=0,salary=0,empNumber=0,temp=1;
			String name=null,designation=null,scheme=null,userResponse=null; 
			
			
			Scanner sc=new Scanner(System.in);
			
			
			System.out.println("Enter number of Employees:");
			empNumber=sc.nextInt();
			
			
			
			
		do {
			
			Employee emp=new Employee();
			
			try {
			System.out.println("Enter id of "+temp+"th Employee :");
			id=sc.nextInt();
			emp.setId(id);
			
			System.out.println("Enter Name of "+temp+"th Employee :");
			name=sc.next();
			emp.setName(name);
			
			System.out.println("Enter Salary of "+temp+"th Employee :");
			salary=sc.nextInt();
			emp.setSalary(salary);
			
			System.out.println("Enter Designation of "+temp+"th Employee:");
			designation=sc.next();
			emp.setDesignation(designation);
					
			
			emp.setScheme();
			
			

			
			if(salary<3000)
			
				throw new ExceptionCheck();
			
			}
			
			catch(ExceptionCheck e)
			{
				System.out.println(e);
			}
			
			emp.DisplayEmployee();
			
			ServicesOffered svcOffered=new ServicesOffered();
			svcOffered.Services(emp.getScheme());
			
			
			
			FileOutputStream fos=null;
			ObjectOutputStream oos;
			
			Service sr=new Service(id,salary,name,designation);
			
			try
			{
				fos =new FileOutputStream("EmpObj.obj",true);
				oos=new ObjectOutputStream(fos);
				oos.writeObject(sr);
				
				FileReader fr=new FileReader("D:\\Sayon Banik\\My project\\EmpObj.obj");
				BufferedReader br=new BufferedReader(fr);
		//		String fileContent=br.readLine();
		//		System.out.println(fileContent);
				
				FileInputStream fis=new FileInputStream("D:\\Sayon Banik\\My project\\EmpObj.obj");
				ObjectInputStream ois=new ObjectInputStream(fis);
				Service sr2=(Service)ois.readObject();
				System.out.println(sr2);
				
				
			} 
			
			catch (IOException |ClassNotFoundException e)
			{
				
				e.printStackTrace();
			}
			
			
			
			temp++;
			
			
	
		}while(temp<=empNumber);
	}

}
