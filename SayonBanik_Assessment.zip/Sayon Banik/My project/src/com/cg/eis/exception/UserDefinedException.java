package com.cg.eis.exception;

public class UserDefinedException extends Exception {
	String message;
	
	public UserDefinedException() 
	{
		message="Error,Salary should be greater than rs. 3000. Kindly check again and retry";
	}

	@Override
	public String toString() {
		return message;
	}
	
	

}
