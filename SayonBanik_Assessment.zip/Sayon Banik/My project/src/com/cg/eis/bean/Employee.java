package com.cg.eis.bean;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Employee {

	private int id;
	public String name;
	private int salary;
	String designation;
	private String scheme;
	
	
	//Collection<Employee> arList=new Collection<Employee>();
	
	

	
	
	public void DisplayEmployee()
	{
		
		System.out.println("Employee Id:"+id);
		System.out.println("Employee Name:"+name);
		System.out.println("Employee Salary:"+salary);
		System.out.println("Employee Designation:"+designation);
		System.out.println("Employee Scheme:"+getScheme());
		
	
	}

	
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getSalary() {
		return salary;
	}


	public void setSalary(int salary) {
		this.salary = salary;
	}


	public String getDesignation() {
		return designation;
	}


	public void setDesignation(String designation) {
		this.designation = designation;
	}


	public String getScheme() {
		return scheme;
	}


	public void setScheme() {
		if(salary>5000 && salary<20000 && designation.equals("SystemAssociate")) {
			this.scheme="C";
		//	System.out.println("Employee scheme is:"+scheme);
		}
		
		else if(salary>=20000 && salary<40000 && designation.equals("Programmer")) {
			this.scheme="B";
		//	System.out.println("Employee scheme is:"+scheme);
		}
		
		else if(salary>=40000 && designation.equals("Manager") ) {
			this.scheme="A";
		//	System.out.println("Employee scheme is:"+scheme);
		}
		
		else if(salary<5000 && designation.equals("Clerk")){
			this.scheme="No Scheme";
		//	System.out.println("Employee scheme is:"+scheme);
		}
	}


	@Override
	public String toString() {
		return "Employee details: Employee Id:"+id+" Employee Name:"+name+" Employee Salary:"+salary;
	}
}
