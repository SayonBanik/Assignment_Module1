
public class EmptyFieldException extends Exception {

	String message;
	
	EmptyFieldException()
	{
		message = "First Name or Last Name is missing, please check and try again";
	}
	
	public String toString()
	{
		return message;
	}
}
