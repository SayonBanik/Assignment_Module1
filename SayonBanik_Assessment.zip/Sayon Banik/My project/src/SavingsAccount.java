public class SavingsAccount extends Account {

	final long minimumBalance=2500;
	
	public SavingsAccount() {
		super();
	}
	
	public void Withdraw(double currBalance)
	{
		if(currBalance<minimumBalance)
			System.out.println("Current balance is less than minimum balance, cannot withdraw money");
		else
			System.out.println("Current balance is not less than minimum balance, ready to withdraw money");
	}


}
