import java.util.Iterator;
import java.util.Scanner;
import java.io.*;



public class PersonMain {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		String firstName = null;
		String lastName = null;
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		Scanner sc=new Scanner(System.in);
		
	try {
		System.out.println("Enter First Name:");
			 firstName=br.readLine();
			 
		System.out.println("Enter Last Name:");
			 lastName=br.readLine();
			 
		if(firstName.equals("") || lastName.equals(""))
		{
			throw new EmptyFieldException();
		}
	}
	
	catch(EmptyFieldException e)
	{
		System.out.println(e);
	}
		
		System.out.println("Enter Gender:");
			String g=br.readLine();
			
		System.out.println("Enter Age:");
			float age=sc.nextFloat();
		
		char gender=g.charAt(0);
		
		
		Person obj=new Person(firstName, lastName, gender);
		
		obj.Display();
		

		
		/*obj.setFirstName(firstName);
		obj.setLastName(lastName);
		obj.setGender(gender);*/
		
		
	}
}
