
class Account extends Person
{

	static long temp=287000;
	long accNum=0;
	double balance=0.0;
	String name=null;
	float age;
	Person accHolder;
	
	
	public Account() {}
	
	
	public Account(Person person) {
		// TODO Auto-generated constructor stub
		this.accHolder=person;
		
		accNum=temp++;
		
		System.out.println("Name:"+accHolder.name);
		System.out.println("Age:"+accHolder.age);
		System.out.println("Account Number:"+accNum);
	}


	public void Withdraw() {}
	
	public boolean withdraw() {return false;}


	public double getBalance() {
		// TODO Auto-generated method stub
		return balance;
	}


	public void setBalance(long accNumber, double balance, int modifier) {
		// TODO Auto-generated method stub
		
		if(accNumber==287000)
			this.balance=balance+modifier;
		else if(accNumber==287001)
			this.balance=balance-modifier;
	}
}



