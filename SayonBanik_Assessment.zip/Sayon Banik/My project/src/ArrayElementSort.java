import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class ArrayElementSort {
	
	
	public static void main(String [] args)
	{
		int length;
		
		Scanner sc=new Scanner(System.in);
		
		
		System.out.println("Enter the number of elements");
		length=sc.nextInt();
		
		String [] arr=new String[length];
		 
		System.out.println("Enter the elements");
		
		for(int i=0;i<length;i++)
			arr[i]=sc.next();
		
		
		System.out.println("Array before sorting");
		
		for(int i=0;i<length;i++)
			System.out.println(arr[i]);
		
		Arrays.sort(arr);
		
		
		System.out.println("Array after sorting");
				
		for(int i=0;i<length;i++)
			System.out.println(arr[i]);
		
		
	}
	

}
