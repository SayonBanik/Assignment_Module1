
public class UserRestrictedException extends Exception {
	String message;
	
	UserRestrictedException()
	{
		message="People under the age of 15 years are not authorised to withdraw money";
	}

	public String toString()
	{
		return message;
	}
}
