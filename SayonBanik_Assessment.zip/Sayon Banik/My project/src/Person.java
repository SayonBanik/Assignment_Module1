
	class Person {
		private String firstName;
		private String lastName;
		private char gender;
		protected float age;
		protected String name;
		
		Account ac;
		
		
		public Person() {}
		
		public Person(String firstName, String lastName, char gender) {
			
			this.firstName=firstName;
			this.lastName=lastName;
			this.gender=gender;
		}
		
		
		public Person(String name, float age, double balance) {
			// TODO Auto-generated constructor stub
			this.name=name;
			this.age=age;
			ac=new Account(this);
		}

		public void setFirstName(String firstName)
		{
			// TODO Auto-generated constructor stub
			this.firstName=firstName;
		}
		
		public void setLastName(String lastName)
		{
			// TODO Auto-generated constructor stub
		}
		
		public void setGender(char gender)
		{
			// TODO Auto-generated constructor stub
		}
		
		public void setAge(float age)
		{
			// TODO Auto-generated constructor stub
			this.age=age;
		}
		
		
		public String getFirstName()
		{
			// TODO Auto-generated constructor stub
				return firstName;
		}
		
		public String getLastName()
		{
			// TODO Auto-generated constructor stub
				return lastName;
		}
		
		public char getGender()
		{
			// TODO Auto-generated constructor stub
				return gender;
		}
		
		public float getAge()
		{
			// TODO Auto-generated constructor stub
			return age;
		}
		
		public void Display()
		{
			System.out.println("Person Details:");
			System.out.println("_______________");
			System.out.println("");
			System.out.println("First Name:"+ getFirstName());
			System.out.println("Last Name:"+ getLastName());
			System.out.println("Gender:"+ getGender());
		}
	}

