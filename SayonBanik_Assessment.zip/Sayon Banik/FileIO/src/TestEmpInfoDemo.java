import java.io.*;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class TestEmpInfoDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Emp Id:");
		int eid=sc.nextInt();
		System.out.println("Enter Emp Name:");
		String enm=sc.next();
		System.out.println("Enter Emp Salary:");
		float esl=sc.nextFloat();
		
		FileOutputStream fos=null;
		
		DataOutputStream dos=null;
		
		try
		{
			fos=new FileOutputStream("EmpInfo.txt");
			
			dos=new DataOutputStream(fos);
			dos.writeInt(eid);
			dos.writeUTF(enm);
			dos.writeFloat(esl);
			
			System.out.println("All info written in the file");
		}
		
		
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
