import java.io.*;

public class TestEmpDeserDemo {
	
	public static void main(String [] args) 
	{
		FileInputStream fis=null;
		ObjectInputStream ois=null;
		
		try
		{
			fis=new FileInputStream("EmpObjs.obj");
			ois=new ObjectInputStream(fis);
			Employee ee=(Employee)ois.readObject();
			System.out.println("Emp info from file:"+ee);
		}
		
		catch (ClassNotFoundException  | IOException e)
		{
			// TODO Auto-generated catch block
			 e.printStackTrace();
		}
	}

}
