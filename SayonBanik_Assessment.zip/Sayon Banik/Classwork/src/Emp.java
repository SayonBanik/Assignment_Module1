

public class Emp implements Comparable<Emp>
{
	
	int empId;
	String empName;
	float empSal;
	
	public Emp() {}
	
	@Override
	public String toString() {
		return "Emp [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + "]";
	}

	public Emp(int empId, String empName, float empSal) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
	}


	@Override
	public boolean equals(Object obj)
	{
		Emp ee=(Emp)obj;
		if(this.empId==ee.empId)
		{
			return true;
			}
		else
			return false;
	}



	@Override
	public int hashCode()
	{
		return empId;
	}



	public int compareTo(Emp ee)
	{
		if(this.empId<ee.empId)
		{
			return -1;
		}
		
		else if(this.empId==ee.empId)
		{
			return 0;
		}
		
		else
		{
			return +1;
		}
	}






}