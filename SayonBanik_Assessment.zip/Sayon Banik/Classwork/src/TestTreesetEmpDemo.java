import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class TestTreesetEmpDemo 
{

	public static void main(String[] args)
	{
		
		
		TreeSet<Emp> intSet=new TreeSet<Emp>();
		
		Emp i1=new Emp(40000,"sayon",900.0F);
		Emp i2=new Emp(40001,"sam",9001.0F);
		Emp i3=new Emp(40000,"sayon",900.0F);
		Emp i4=new Emp(40003,"dhruv",9000.0F);
		
		intSet.add(i1);
		intSet.add(i2);
		intSet.add(i3);
		intSet.add(i4);
		
		Iterator<Emp> it=intSet.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());

		}

	}
}
