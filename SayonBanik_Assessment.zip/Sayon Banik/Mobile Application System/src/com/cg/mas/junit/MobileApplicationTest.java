package com.cg.mas.junit;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mas.dto.MobileInfo;
import com.cg.mas.dto.PurchaseDetails;
import com.cg.mas.exception.CustomerException;
import com.cg.mas.service.CustServiceImpl;

public class MobileApplicationTest
{

	static PurchaseDetails pstest=null;
	static PurchaseDetails pstest2=null;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception
	{
		java.util.Date utilDate=new java.util.Date();
		java.sql.Date sqlDate=new java.sql.Date(utilDate.getTime());
		pstest=new PurchaseDetails(200,"Purav","purav@gmail.com","9865741230",sqlDate,1002);
		pstest2=new PurchaseDetails(200,"purav","purav@gmail.com","9865741230",sqlDate,1000);

	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() throws CustomerException
	{
		CustServiceImpl csiTest=new CustServiceImpl();
		
		Assert.assertEquals(1, csiTest.addCust(pstest));
		
		
	}
	
	@Test(expected=CustomerException.class)
	public void test2() throws CustomerException
	{
		CustServiceImpl csiTest2=new CustServiceImpl();
		
		Assert.assertEquals(1, csiTest2.addCust(pstest2));
		
	}
	
	@Test
	public void test3() throws CustomerException
	{
		CustServiceImpl csiTest3=new CustServiceImpl();
		
		ArrayList<MobileInfo>  arr=csiTest3.getSelectedCust(10000,50000);
		
		Assert.assertEquals(false,arr.isEmpty());
		
	}
	
	@Test
	public void test4() throws CustomerException
	{
		CustServiceImpl csiTest3=new CustServiceImpl();
		
		ArrayList<MobileInfo>  arr=csiTest3.getSelectedCust(50000,10000);
		
		Assert.assertEquals(true,arr.isEmpty());
		
	}

}
