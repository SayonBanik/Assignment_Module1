package com.cg.mas.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.mas.exception.CustomerException;
import com.cg.mas.dao.CustDaoImpl;
import com.cg.mas.dto.MobileInfo;
import com.cg.mas.dto.PurchaseDetails;
import com.cg.mas.exception.CustomerException;

public class CustServiceImpl implements CustService
{

	CustDaoImpl custDao=null;
	
	
	public CustServiceImpl()
	{
		custDao=new CustDaoImpl();
	}

	@Override
	public ArrayList<PurchaseDetails> getAllCust() throws CustomerException
	{
		
		return custDao.getAllCust();
	}

	@Override
	public int addCust(PurchaseDetails ps) throws CustomerException
	{
		
		return custDao.addCust(ps);
	}

	@Override
	public ArrayList<MobileInfo> getSelectedCust(int input1,int input2) throws CustomerException
	{
		return custDao.getSelectedCust(input1,input2);
	}

	@Override
	public int DeleteMobDetails(int mId)
	{
		
		return custDao.DeleteMobDetails(mId);
	}

	@Override
	public ArrayList<MobileInfo> DisplayMobileDetails()
	{
		
		return custDao.DisplayMobileDetails();
	}

	@Override
	public boolean validateCustMobileNo(String phnNo) throws CustomerException
	{
		
		String numberPattern="[1-9][0-9]{9}";
		if(Pattern.matches(numberPattern, phnNo))
		{
			return true;
		}
		
		else
		{
			throw new CustomerException("Invalid Customer. Mobile Number should be of exact 10 digits.");
		}
		
	}
	
	@Override
	public boolean validateCustName(String eName) throws CustomerException
	{
		
		String namePattern="[A-Z][a-z]+";
		if(Pattern.matches(namePattern, eName))
		{
			return true;
		}
		
		else
		{
			throw new CustomerException("Invalid Customer Name. Should start with capital. Only characters allowed");
		}
	}

	@Override
	public boolean validateCustEmail(String eMailId) throws CustomerException
	{
		String emailPattern="[a-z]+@+[a-z]+.[a-z]+";
		if(Pattern.matches(emailPattern, eMailId))
		{
			return true;
		}
		
		else
		{
			throw new CustomerException("Invalid Customer Email.Should match the format (example@example.example)");
		}
	}


}
