package com.cg.mas.service;

import java.util.ArrayList;

import com.cg.mas.dto.MobileInfo;
import com.cg.mas.dto.PurchaseDetails;
import com.cg.mas.exception.CustomerException;
import com.cg.mas.dto.PurchaseDetails;
import com.cg.mas.exception.CustomerException;

public interface CustService
{

	public ArrayList<PurchaseDetails> getAllCust()throws CustomerException;
	
	public ArrayList<MobileInfo> getSelectedCust(int input1, int input2)throws CustomerException;
	
	public int addCust(PurchaseDetails ps) throws CustomerException;
	
	public boolean validateCustName(String eName) throws CustomerException;
	
	public boolean validateCustEmail(String eMailId) throws CustomerException;

	public int DeleteMobDetails(int mId);

	public ArrayList<MobileInfo> DisplayMobileDetails();

	public boolean validateCustMobileNo(String phnNo) throws CustomerException;
	
}
