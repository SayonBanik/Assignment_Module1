package com.cg.mas.ui;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import com.cg.mas.dto.MobileInfo;
import com.cg.mas.dto.PurchaseDetails;
import com.cg.mas.exception.CustomerException;
import com.cg.mas.dto.PurchaseDetails;
import com.cg.mas.exception.CustomerException;
import com.cg.mas.service.CustServiceImpl;
import com.cg.mas.dto.PurchaseDetails;
import com.cg.mas.service.CustService;
import com.cg.mas.service.CustServiceImpl;

public class CustMobSystem {

	static CustService custService=null;
	static Scanner sc=null;
	static int pId=100;
	
	public static void main(String[] args) throws ParseException
	{
		

		sc=new Scanner(System.in);
		custService=new CustServiceImpl();
		System.out.println("****** Welcome to MAS ******");
		int choice=0;
		
		while(true)
		{
			System.out.println("What do you want to do?");;
			System.out.println("\t 1: Add Customer \t 2: Show All Customers \t 3:Update Customers \t 4: Delete Mobile Details \t 5: Display Mobile Details \t 6: Exit");
			System.out.println("Enter your choice");
			choice = sc.nextInt();

			switch(choice)
			{
			case 1: insertCustomer();break;
			case 2: displayAllCustomer();break;
			case 3: searchCustomer(); break;
			case 4: deleteMobDetails(); break;
			case 5: displayMobileDetails(); break;
			default: System.exit(0);
			}
		}
		
		
	}

	private static void displayMobileDetails()
	{
		
		ArrayList<MobileInfo> dispMob=null;
		
		dispMob=custService.DisplayMobileDetails();
		System.out.println(" \t MOB_ID \t MOB_NAME \t MOB_PRICE \t MOB_QUANTITY ");
		
		for(MobileInfo mobinfo: dispMob)
		{
			System.out.println("\t"+mobinfo.getMobileId()+"\t"+mobinfo.getMobName()+"\t"+mobinfo.getMobPrice()+"\t"+mobinfo.getMobQuantity());
		}
	}

	private static void deleteMobDetails()
	{
		
		System.out.println("Enter Mobile Id whose record need to be deleted:");
		int mId=sc.nextInt();
		
		int status=custService.DeleteMobDetails(mId);
		
		if(status==0)
		{
			try 
			{
				throw new CustomerException("Cannot delete record.Corresponding Id has records in another table.");
			}
			
			catch (CustomerException e)
			{
				
				e.printStackTrace();
			}
		}
			
		else if(status==1)
		{
			System.out.println(status+" Mobile details is deleted successfully.");
			System.out.println("Select option 5 to see mobile details");
		}
	}

	private static void searchCustomer()
	{
		ArrayList <MobileInfo> selectedtList=null;
		
		try
		{
			System.out.println("Enter range to see mobile details");
			System.out.println("Enter lower Limit:");
			int input1=sc.nextInt();
			
			System.out.println("Enter upper Limit:");
			int input2=sc.nextInt();
			
			selectedtList=custService.getSelectedCust(input1,input2);
			System.out.println(" \t MOB_ID \t MOB_NAME \t MOB_PRICE \t MOB_QUANTITY ");
			
			
			for(MobileInfo mi:selectedtList)
			{
				System.out.println("\t"+mi.getMobileId()+"\t"+mi.getMobName()+"\t"+mi.getMobPrice()+"\t"+mi.getMobQuantity());
			}
			
			
		}
		
		catch (CustomerException e)
		{

			e.printStackTrace();
		}
		
		
	}

	private static void displayAllCustomer()
	{
		ArrayList <PurchaseDetails> custList=null;
		try
		{
			custList=custService.getAllCust();
			System.out.println(" \t purchaseID \t cName \t mailID \t phoneNO \t purchaseDate \t MOB_ID");
			for(PurchaseDetails pd:custList)
			{
				System.out.println("\t"+pd.getPurchaseId()+"\t"+pd.getcName()+"\t"+pd.getMailId()+"\t"+pd.getPhoneNumber()+"\t"+pd.getDate()+"\t"+pd.getMobileId());
			}
		}
		catch(CustomerException e)
		{
			e.printStackTrace();
		}
		
	}

	private static void insertCustomer() throws ParseException
	{
		String mailId=null;
		String phnNo=null;
		int mobId=0;
		try
		{
			
			System.out.println("Enter Name");
			String enm=sc.next();
			
			if(custService.validateCustName(enm))
			{
				System.out.println("Enter mail id:");
				mailId=sc.next();	
			}
				
			if(custService.validateCustEmail(mailId))
			{
				System.out.println("Enter phone no:");
				phnNo=sc.next();
			}	
			
			if(custService.validateCustMobileNo(phnNo))
			{
				System.out.println("Enter mobile id:");
				mobId=sc.nextInt();
				
			}
			
			java.util.Date utilDate=new java.util.Date();
			java.sql.Date sqlDate=new java.sql.Date(utilDate.getTime());
					
					
			PurchaseDetails c1=new PurchaseDetails(pId,enm,mailId,phnNo,sqlDate,mobId);
					
	
					int dataInserted=custService.addCust(c1);
					if(dataInserted==1)
					{
						displayAllCustomer();
					}
					else
					{
						System.out.println("Sorry data is not inserted");
					}
					
			
			
		}
		catch (CustomerException e) 
		{
		
			e.printStackTrace();
		}
		
		
		
		
		pId++;
	}

}
