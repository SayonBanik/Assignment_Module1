package com.cg.mas.dto;

import java.sql.Date;

public class PurchaseDetails
{

	private int purchaseId=0;
	private String cName=null;
	private String mailId=null;
	private String phoneNumber;
	private Date purchaseDate;
	private int mobileId=0;
	
	public PurchaseDetails()
	{
		super();
		
	}

	public PurchaseDetails(int purchaseId, String cName, String mailId, String phoneNumber, Date date, int mobileId) {
		super();
		this.purchaseId = purchaseId;
		this.cName = cName;
		this.mailId = mailId;
		this.phoneNumber = phoneNumber;
		this.purchaseDate = date;
		this.mobileId = mobileId;
	}

	@Override
	public String toString() {
		return "PurchadeDetails [purchaseId=" + purchaseId + ", cName=" + cName + ", mailId=" + mailId
				+ ", phoneNumber=" + phoneNumber + ", date=" + purchaseDate + ", mobileId=" + mobileId + "]";
	}

	public int getPurchaseId() {
		return purchaseId;
	}

	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Date getDate() {
		return purchaseDate;
	}

	public void setDate(Date date) {
		this.purchaseDate = date;
	}

	public int getMobileId() {
		return mobileId;
	}

	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	
	
	
	
}
