package com.cg.mas.dto;

public class MobileInfo
{

	private int mobileId;
	private String mobName;
	private int mobPrice;
	private String mobQuantity;
	
	
	public MobileInfo()
	{
		super();
		
	}


	public MobileInfo(int mobileId, String mobName, int mobPrice, String mobQuantity) {
		super();
		this.mobileId = mobileId;
		this.mobName = mobName;
		this.mobPrice = mobPrice;
		this.mobQuantity = mobQuantity;
	}


	@Override
	public String toString() {
		return "MobileInfo [mobileId=" + mobileId + ", mobName=" + mobName + ", mobPrice=" + mobPrice + ", mobQuantity="
				+ mobQuantity + "]";
	}


	public int getMobileId() {
		return mobileId;
	}


	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}


	public String getMobName() {
		return mobName;
	}


	public void setMobName(String mobName) {
		this.mobName = mobName;
	}


	public int getMobPrice() {
		return mobPrice;
	}


	public void setMobPrice(int mobPrice) {
		this.mobPrice = mobPrice;
	}


	public String getMobQuantity() {
		return mobQuantity;
	}


	public void setMobQuantity(String mobQuantity) {
		this.mobQuantity = mobQuantity;
	}
	
	
}
