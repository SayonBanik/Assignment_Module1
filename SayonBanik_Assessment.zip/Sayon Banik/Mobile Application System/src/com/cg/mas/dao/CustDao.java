package com.cg.mas.dao;

import java.util.ArrayList;

import com.cg.mas.exception.CustomerException;
import com.cg.mas.dto.MobileInfo;
import com.cg.mas.dto.PurchaseDetails;
import com.cg.mas.exception.CustomerException;

public interface CustDao
{

	public ArrayList<PurchaseDetails> getAllCust()throws CustomerException;
	
	public int addCust(PurchaseDetails ps) throws CustomerException;

	public ArrayList<MobileInfo> getSelectedCust(int input1, int input2)throws CustomerException;
	
	public int DeleteMobDetails(int mId);
	
	public ArrayList<MobileInfo> DisplayMobileDetails();

}
