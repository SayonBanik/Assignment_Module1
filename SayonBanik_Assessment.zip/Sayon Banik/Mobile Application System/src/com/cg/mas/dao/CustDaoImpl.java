package com.cg.mas.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mas.exception.CustomerException;
import com.cg.mas.util.CustUtil;
import com.cg.mas.dto.MobileInfo;
import com.cg.mas.dto.PurchaseDetails;
import com.cg.mas.exception.CustomerException;
import com.cg.mas.util.CustUtil;
import com.cg.mas.dto.PurchaseDetails;
import com.cg.mas.util.CustUtil;
import com.cg.mas.dto.PurchaseDetails;
import com.cg.mas.exception.CustomerException;

public class CustDaoImpl implements CustDao
{


	Connection con=null;
	Statement st=null;
	PreparedStatement pst,pst2,pst3,pst4,pst5,pst6=null;
	ResultSet rs,rs2,rs4,rs6=null;
	
	
	@Override
	public ArrayList<PurchaseDetails> getAllCust() throws CustomerException 
	{
		ArrayList<PurchaseDetails> empList=null;
		
		empList=new ArrayList<PurchaseDetails>();
		try
		{
			con=CustUtil.getConn();
			String selectqry="SELECT * FROM purchasedetails_157998";
			st=con.createStatement();
			rs=st.executeQuery(selectqry);
			while(rs.next())
			{
				empList.add(new PurchaseDetails(rs.getInt("purchaseID"),
						rs.getString("cNAME"),
						rs.getString("mailID"),rs.getString("phoneNO"),rs.getDate("purchaseDATE"),rs.getInt("MOB_IDf")));
			}
			
		}
		
		catch (Exception e)
		{
			
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		}
		
		finally
		{
			try
			{
				st.close();
				rs.close();
				con.close();
			}
			
			catch(SQLException e)
			{
				e.printStackTrace();
				throw new CustomerException(e.getMessage());
			}
		}
		
		return empList;

	}

	@Override
	public int addCust(PurchaseDetails ps) throws CustomerException
	{
	
		int data;
		try
		{
			con=CustUtil.getConn();
			
			String insertQry="INSERT INTO purchasedetails_157998 VALUES(?,?,?,?,?,?)";
			String opRes="SELECT MOB_QUANTITY FROM mobiles_157998 WHERE MOB_ID=?";
			String modifyDb="UPDATE mobiles_157998 SET MOB_QUANTITY=MOB_QUANTITY-1 WHERE MOB_ID=?";
			
			int i=0;
			
			
			
			pst2=con.prepareStatement(opRes);
			pst2.setInt(1,ps.getMobileId() );
			rs2=pst2.executeQuery();
			
			while(rs2.next())
			{
				i=rs2.getInt("MOB_QUANTITY");
			}
			
			if(i>0)
			{
				pst=con.prepareStatement(insertQry);
				pst.setInt(1, ps.getPurchaseId());
				pst.setString(2, ps.getcName());
				pst.setString(3, ps.getMailId());
				pst.setString(4, ps.getPhoneNumber());
				pst.setDate(5, (Date) ps.getDate());
				pst.setInt(6, ps.getMobileId());
				
				data=pst.executeUpdate();
				
				pst3=con.prepareStatement(modifyDb);
				pst3.setInt(1, ps.getMobileId());
				pst3.executeUpdate();
				
				
			}
			

			else
			{
				throw new CustomerException("Out of stock");
			}
			
			
		}
		
		catch (Exception e) {
			
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		}
		
		return data;
	}

	@Override
	public ArrayList<MobileInfo> getSelectedCust(int input1, int input2) throws CustomerException
	{
		ArrayList<MobileInfo> selectedList=null;
		
		selectedList=new ArrayList<MobileInfo>();
		try
		{
			con=CustUtil.getConn();
			String selectqry="SELECT * FROM mobiles_157998 WHERE MOB_PRICE BETWEEN ? AND ?";
			pst4=con.prepareStatement(selectqry);
			pst4.setInt(1,input1 );
			pst4.setInt(2,input2 );
			
			rs=pst4.executeQuery();
			
			while(rs.next())
			{
				selectedList.add(new MobileInfo(rs.getInt("MOB_ID"),
						rs.getString("MOB_NAME"),
						rs.getInt("MOB_PRICE"),rs.getString("MOB_QUANTITY")));
			}
		} 
		
		catch (Exception e)
		{
			
			e.printStackTrace();
		} 
		
		
		return selectedList;
	}

	@Override
	public int DeleteMobDetails(int mId)
	{
		int deleteStatus=0;
		
		try 
		{
			con=CustUtil.getConn();
			
			pst5=con.prepareStatement("DELETE FROM mobiles_157998 WHERE MOB_ID=?");
			pst5.setInt(1, mId);
			deleteStatus=pst5.executeUpdate();
			
		}
		
		
		catch (Exception e) 
		{
			
			e.printStackTrace();
		
		}
		
		
		
		
		return deleteStatus;
	}

	public ArrayList<MobileInfo> DisplayMobileDetails()
	{
	
		ArrayList<MobileInfo> dispMobile=new ArrayList<MobileInfo>();
		
		try
		{
			con=CustUtil.getConn();
			pst6=con.prepareStatement("SELECT * FROM mobiles_157998");
			rs=pst6.executeQuery();
			
			while(rs.next())
			{
				dispMobile.add(new MobileInfo(rs.getInt("MOB_ID"),
						rs.getString("MOB_NAME"),
						rs.getInt("MOB_PRICE"),rs.getString("MOB_QUANTITY")));
			}
		}
		
		catch (SQLException | IOException e) {
			
			e.printStackTrace();
		}
		
		
		return dispMobile;
	}

	




}
